<?php 
session_start();

include ("include/connection.php");
	
	if (isset($_POST['sign_in'])) {
		$hp = htmlentities(mysqli_real_escape_string($con, $_POST['hp']));
		$pass = htmlentities(mysqli_real_escape_string($con, $_POST['pass']));

		$select_user = "SELECT * from users where user_hp='$hp' AND user_pass='$pass'";
		$query = mysqli_query($con, $select_user);
		$check_user = mysqli_num_rows($query);

		if ($check_user == 1 ) {
			$_SESSION['user_hp']=$hp;

			$update_msg = mysqli_query($con, "UPDATE users SET log_in='online' WHERE user_hp = '$hp'");
			$user = $_SESSION['user_hp'];
			$get_user = "select * from users where user_hp='$user'";
			$run_user = mysqli_query($con, $get_user);
			$row = mysqli_fetch_array($run_user);

			$user_name = $row['user_name'];

			echo "<script>window.open('home.php?user_name=$user_name', '_self')</script>";
		}
		else{
			echo "
			<div class='alert alert-danger'>
				<strong>Check your hp and password. </strong>
			</div>
			";
		}
	}
?>