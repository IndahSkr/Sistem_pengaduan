<?php
include ("include/connection.php");

	if (isset($_POST['sign_up'])) {
		$name = htmlentities(mysqli_real_escape_string($con, $_POST['user_name']));
		$pass = htmlentities(mysqli_real_escape_string($con, $_POST['user_password']));
		$hp = htmlentities(mysqli_real_escape_string($con, $_POST['user_hp']));
		$kec = htmlentities(mysqli_real_escape_string($con, $_POST['user_kecamatan']));
		$gender = htmlentities(mysqli_real_escape_string($con, $_POST['user_gender']));
		$rand = rand(1, 2);

		if ($name == '') {
			echo "<script>alert('we can not verify your name')</script>";
		}
		if (strlen($pass)<8) {
			echo "<script>alert('Password harus lebih dari 8 karakter!')</script>";
			exit();
		}

		$check_hp = "select * from users where user_email='$mail'";
		$run_email = mysqli_query($con, $check_email);

		$check = mysqli_num_rows($run_hp);

		if($check==1){

			echo "<script>alert('Hp sudah ada'</script>)";
			echo "<script>window.open('signup.php,'_self')</script>";
			exit();
		}

		if ($rand == 1) {
			$profile_pic = "images/krunk.jpg";}
		elseif ($rand == 2) {
			$profile_pic = "images/koya.png";
		}
		$insert = "insert into users (user_name, user_pass, user_hp, user_profile, user_kecamatan, user_gender) values('$name', '$pass', '$hp', '$profile_pic', '$kec', '$gender')";
		$query = mysqli_query($con, $insert);
		if ($query) {
			echo "<script>alert('Congratulations $name, your account has been created seccesfully')</script>";
			echo "<script>window.open('signin.php', '_self')</script>";
		}
		else{
			echo "<script>alert('Registration failed, try again!')</script>";
			echo "<script>window.open('signup.php', '_self')</script>";
		}
		
	}

?>