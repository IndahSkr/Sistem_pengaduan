<?php
	$con = mysqli_connect("localhost", "root", "", "sistem") or die ("connection was not estabilished");
?>